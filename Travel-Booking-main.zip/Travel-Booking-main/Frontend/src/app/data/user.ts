export class user { 
    public userId: any;
    public userName: any;
    public userEmail: any;
    public userAddress: any;
    public userPassword: any;
    public matchingPassword: any;
    public userGender: any;
    public userPhoneNo: any;
    public userNation: any;
    public userDOB: any;
    public isAdmin: any;
    public isEnabled: any;
}

