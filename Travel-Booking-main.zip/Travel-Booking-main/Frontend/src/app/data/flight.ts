import { Time } from "@angular/common";

export class Flight{
    
    public flightName: any;
    public flightSource: any;
    public flightDestination: any;
    public flightDepartureDate: any;
    public flightArrivalDate: any;
    public flightFare: any;
    public flightAvailability: any;
    public flightTotalSeats: any;
    public flightBookedSeats: any;
    public flightLogoUrl: any   

}