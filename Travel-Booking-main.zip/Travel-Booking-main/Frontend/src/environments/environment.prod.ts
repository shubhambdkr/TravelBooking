export const environment = {
  production: true,
  firebase:{
    apiKey: "AIzaSyAkFiBvg2x2X1xBFqchmZIsHwW0v_zFDZY",
    authDomain: "oshop-4c1e7.firebaseapp.com",
    projectId: "oshop-4c1e7",
    storageBucket: "oshop-4c1e7.appspot.com",
    messagingSenderId: "81627622559",
    appId: "1:81627622559:web:a1f0b9fd1dade045cb46aa"
  }
};
