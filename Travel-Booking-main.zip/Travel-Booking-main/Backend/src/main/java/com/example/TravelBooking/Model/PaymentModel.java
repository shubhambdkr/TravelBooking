package com.example.TravelBooking.Model;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class PaymentModel {
    int amount;
    String id;
}
