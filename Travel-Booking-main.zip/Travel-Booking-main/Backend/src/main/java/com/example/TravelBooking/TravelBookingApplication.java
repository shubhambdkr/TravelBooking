package com.example.TravelBooking;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TravelBookingApplication {
	public static void main(String[] args) {
		SpringApplication.run(TravelBookingApplication.class, args);
	}
}
