package com.example.TravelBooking.Model;

public class StringResponse {
    private String data;
    public String getData() {
        return data;
    }
    public void setData(String data) {
        this.data = data;
    }
    public StringResponse(String data) {
        this.data = data;
    }
}
